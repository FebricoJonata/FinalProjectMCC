package com.example.final_project_mcc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
