class Hosting {
  // for mobile device
  static const String main = "http://192.168.68.179:3000";

  // for emulator
  // static const String main = "http://10.0.2.2:3000";
}
